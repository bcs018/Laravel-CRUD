<h2>Lista completa de Livros</h2>

<?php if(count($list) == 0): ?>
    <h4>Não há livros cadastrados</h4>
<?php else: ?> 
    <?php $__currentLoopData = $list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <ul>
            <li> <?php echo e($item->nome); ?> <a href="<?php echo e(route('livros.edit',["id"=>$item->id])); ?>">Editar</a> | <a onclick="return confirm('Deseja excluir este item?')" href="<?php echo e(route('livros.delete',["id"=>$item->id])); ?>">Excluir</a> </li>
        </ul>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>

<hr>

<a  href="<?php echo e(route('livros.save')); ?>"><button>Clique aqui para cadastrar</button></a>

<br><br><br><br>

<h3>Pesquisar</h3>
<form action="<?php echo e(route('livros.show')); ?>" method="POST">
    <?php echo csrf_field(); ?>
    Pesquisar livro por id: <br>
    <input type="number" name="id_livro"> <br><br>

    <input type="submit" value="Pesquisar">

</form>

<hr>

<form action="<?php echo e(route('livros.search')); ?>" method="POST">
    <?php echo csrf_field(); ?>
    Pesquisar livro por texto: <br>
    <input type="text" name="txt_livro"> <br><br>

    <input type="submit" value="Pesquisar">

</form>

<hr>

<?php if(isset($livro)): ?>
    <?php if(count($livro) == 0): ?>
        <h4>Não há livros encontrados</h4>
    <?php else: ?> 
        <?php $__currentLoopData = $livro; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <ul>
                <li> <?php echo e($item->nome); ?> <a href="<?php echo e(route('livros.edit',["id"=>$item->id])); ?>">Editar</a> | <a onclick="return confirm('Deseja excluir este item?')" href="<?php echo e(route('livros.delete',["id"=>$item->id])); ?>">Excluir</a> </li>
            </ul>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\projeto\projeto\resources\views/index.blade.php ENDPATH**/ ?>