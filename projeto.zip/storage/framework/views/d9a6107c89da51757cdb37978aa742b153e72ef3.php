<h1>Cadastro de livros</h1>

<a href="<?php echo e(route('livros.list')); ?>">Home</a>
<br><br><br>

<form action="<?php echo e(route('livros.add')); ?>" method="post">
    <?php echo csrf_field(); ?>
    Nome do Livro: <br>
    <input type="text" name="nome_livro"> <br><br>

    Categoria do Livro: <br>
    <input type="text" name="categoria"><br><br>

    Autor do Livro: <br>
    <input type="text" name="autor"><br><br>

    Livro é ebook? <br>
    <input type="radio" name="ebook" id="ebookt" value="1"><label for="ebookt">SIM</label> <br>
    <input type="radio" name="ebook" id="ebookf" value="0"><label for="ebookf">NÂO</label> <br><br>
    
    Tamanho do arquivo: <br>
    <input type="number" name="tamanho_arq"><br><br>
    
    Peso do arquivo: <br>
    <input type="number" name="peso"><br><br>

    Selecione a pessoa responsável: <br>
    <select name="pessoa">
        <?php $__currentLoopData = $list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($item->id); ?>"><?php echo e($item->nome); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
    <br><br>

    <input type="submit" value="Cadastrar">
</form><?php /**PATH C:\xampp\htdocs\projeto\projeto\resources\views/cadastrar.blade.php ENDPATH**/ ?>