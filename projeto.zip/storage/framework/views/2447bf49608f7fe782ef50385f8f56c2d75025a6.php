<h1>Atualizar Livro</h1>

<a href="<?php echo e(route('livros.list')); ?>">Home</a>
<br><br><br>

<form action="<?php echo e(route('livros.update')); ?>" method="post">
    <?php echo csrf_field(); ?>

    <input type="hidden" name="id" value="<?php echo e($livro->id); ?>">

    Nome do Livro: <br>
    <input type="text" name="nome_livro" value="<?php echo e($livro->nome); ?>"> <br><br>

    Categoria do Livro: <br>
    <input type="text" name="categoria" value="<?php echo e($livro->categoria); ?>"><br><br>

    Autor do Livro: <br>
    <input type="text" name="autor" value="<?php echo e($livro->autor); ?>"><br><br>

    Livro é ebook? <br>
    <input type="radio" name="ebook" id="ebookt" value="1" <?php echo($livro->ebook=='1')?'checked':'' ?> ><label for="ebookt">SIM</label>  <br>
    <input type="radio" name="ebook" id="ebookf" value="0" <?php echo($livro->ebook=='0')?'checked':'' ?>><label for="ebookf">NÂO</label>  <br><br>
    
    Tamanho do arquivo: <br>
    <input type="number" name="tamanho_arq" value="<?php echo e($livro->tamanho_arquivo); ?>"><br><br>
    
    Peso do arquivo: <br>
    <input type="number" name="peso" value="<?php echo e($livro->peso); ?>"><br><br>

    Selecione a pessoa responsável: <br>
    <select name="pessoa">
        <?php $__currentLoopData = $list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option <?php echo($item->id==$livro->pessoa_id)?'selected':'' ?> value="<?php echo e($item->id); ?>"><?php echo e($item->nome); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
    <br><br>

    <input type="submit" value="Cadastrar">
</form>
<?php /**PATH C:\xampp\htdocs\projeto\projeto\resources\views/atualizar.blade.php ENDPATH**/ ?>