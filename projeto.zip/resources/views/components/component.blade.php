<div style="border: 1px solid #FF0000; padding: 20px">
	{{$slot}} 
</div>